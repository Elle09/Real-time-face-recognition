# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from .models import Records
from django.shortcuts import render
from django.http import HttpResponse
from records.models import Records
# Create your views here.
def index(request):
    records = Records.objects.all()[:10]    #getting the first 10 records
    context = {
        'records': records
    }
    return render(request, 'records.html', context)

def details(request, id):
    record = Records.objects.get(id=id)
    #record = Records.objects.get(first_name=first_name)
    #record = Records.objects.get(last_name=last_name)
    context = {
        'record' : record
    }
    return render(request, 'details.html', context)
